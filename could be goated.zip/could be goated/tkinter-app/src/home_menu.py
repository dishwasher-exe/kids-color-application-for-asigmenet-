import tkinter as tk
from tkinter import Label, Button

class HomeMenu:
    def __init__(self, master):
        self.master = master
        self.master.title("Home Menu")
        self.create_widgets()

    def create_widgets(self):
        self.label = Label(self.master, text="Welcome to the Game Menu", font=("Arial", 24))
        self.label.pack(pady=20)

        self.play_button = Button(self.master, text="Play", command=self.open_game_mode_selector)
        self.play_button.pack(pady=10)

        self.quit_button = Button(self.master, text="Quit", command=self.master.quit)
        self.quit_button.pack(pady=10)

    def open_game_mode_selector(self):
        from game_mode_selector import GameModeSelector
        self.master.destroy()
        new_window = tk.Tk()
        GameModeSelector(new_window)
        new_window.mainloop()