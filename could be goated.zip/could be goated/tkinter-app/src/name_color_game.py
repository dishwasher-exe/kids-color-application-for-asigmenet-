from tkinter import Canvas, Entry, Button
import tkinter as tk  # Import tkinter as tk
from tkinter.colorchooser import askcolor

class NameColorGame:
    def __init__(self, master):
        self.master = master
        self.master.title("Name Color Game")
        
        # Set up canvas
        self.canvas = Canvas(master, width=400, height=400, bg='white')
        self.canvas.pack()

        self.color = 'black'  # Default color
        self.name_entry = Entry(master)
        self.name_entry.pack()

        self.color_button = Button(master, text="Select Color", command=self.select_color)
        self.color_button.pack()

        # X and Y coordinate entry fields
        self.x_entry = Entry(master)
        self.x_entry.pack()
        self.x_entry.insert(0, "200")  # Default X-coordinate

        self.y_entry = Entry(master)
        self.y_entry.pack()
        self.y_entry.insert(0, "200")  # Default Y-coordinate

        # Draw button
        self.draw_button = Button(master, text="Draw Name", command=self.draw_name)
        self.draw_button.pack()

    def select_color(self):
        # Use color chooser to pick a color
        color = askcolor()[1]
        if color:
            self.color = color  # Set the selected color

    def draw_name(self):
        # Get the name from the name entry widget
        name = self.name_entry.get()
        
        # Get X and Y coordinates from entry fields
        try:
            x = int(self.x_entry.get())
            y = int(self.y_entry.get())
        except ValueError:
            # If the entry values are not valid integers, set to default values
            x, y = 200, 200
        
        # Draw the name on the canvas with the selected color
        self.canvas.create_text(x, y, text=name, fill=self.color, font=('Arial', 24))

# Create the Tkinter root window
root = tk.Tk()

# Initialize the game with the root window
app = NameColorGame(root)

# Start the Tkinter main loop
root.mainloop()
