import tkinter as tk
from tkinter import Canvas, Frame, Button

class MSPaintMode:
    pass

class PaintApp:
    def __init__(self, master):
        self.master = master
        self.master.title("MS Paint Mode")
        
        # Canvas for drawing
        self.canvas = Canvas(self.master, bg="white")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.color = "black"
        self.last_x, self.last_y = None, None
        
        # Binding mouse events
        self.canvas.bind("<Button-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)
        
        # Create the color palette
        self.create_color_palette()
        
    def create_color_palette(self):
        # Frame to hold color buttons
        color_frame = Frame(self.master)
        color_frame.pack(side=tk.TOP, fill=tk.X)
        
        # Predefined colors
        colors = ["black", "red", "green", "blue", "yellow", "orange", "purple"]
        for color in colors:
            btn = Button(color_frame, bg=color, command=lambda c=color: self.change_color(c))
            btn.pack(side=tk.LEFT, padx=2, pady=2)
    
    def change_color(self, new_color):
        # Update current color
        self.color = new_color
    
    def on_button_press(self, event):
        # Store the initial mouse coordinates
        self.last_x, self.last_y = event.x, event.y
    
    def on_mouse_drag(self, event):
        # Draw line while mouse is dragged
        if self.last_x is not None and self.last_y is not None:
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y, fill=self.color, width=2)
            self.last_x, self.last_y = event.x, event.y
    
    def on_button_release(self, event):
        # Reset the last coordinates when mouse button is released
        self.last_x, self.last_y = None, None
    
    def save_artwork(self, filename):
        # Save the canvas as an EPS file
        self.canvas.postscript(file=filename + ".eps")

# Create the Tkinter root window
root = tk.Tk()

# Initialize the PaintApp with the root window
app = PaintApp(root)

# Start the Tkinter main loop
root.mainloop()
