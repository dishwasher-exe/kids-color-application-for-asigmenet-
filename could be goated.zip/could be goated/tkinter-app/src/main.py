import tkinter as tk
from tkinter import Label, Button

class HomeMenu:
    def __init__(self, master):
        self.master = master
        self.master.title("Home Menu")

 # Add background image
        self.bg = tk.PhotoImage(file="bk.png")
        self.bg_label = Label(self.master, image=self.bg)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)  # Stretch background


        self.create_widgets()

    def create_widgets(self):
        self.label = Label(self.master, text="Welcome to the Game Menu", font=("Arial", 24), bg="white")
        self.label.pack(pady=20)

        self.play_button = Button(self.master, text="Play", command=self.open_game_mode_selector)
        self.play_button.pack(pady=20)

        self.quit_button = Button(self.master, text="Quit", command=self.master.quit)
        self.quit_button.pack(pady=20)

    def open_game_mode_selector(self):
        from game_mode_selector import GameModeSelector  # Ensure this module exists

        self.master.withdraw()  # Hide the current window

        new_window = tk.Toplevel(self.master)  # Use Toplevel to create a new window
        GameModeSelector(new_window)

# Running the application
if __name__ == "__main__":
    root = tk.Tk()
    app = HomeMenu(root)
    root.mainloop()