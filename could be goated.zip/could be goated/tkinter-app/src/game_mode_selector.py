import tkinter as tk
from tkinter import Label, Button

class GameModeSelector:
    def __init__(self, master):
        self.master = master
        self.master.title("Game Mode Selector")
        
        self.label = Label(master, text="Select a Game Mode", font=("Arial", 16))
        self.label.pack(pady=20)

        self.ms_paint_button = Button(master, text="canvus_game", command=self.open_ms_paint_mode)  # Change this to
                           
        self.ms_paint_button.pack(pady=10)

        self.name_color_game_button = Button(master, text="Name Color Game", command=self.open_name_color_game)
        self.name_color_game_button.pack(pady=10)

    def open_ms_paint_mode(self):
        from canvus_game import MSPaintMode
        self.master.destroy()
        new_window = tk.Tk()
        MSPaintMode(new_window)
        new_window.mainloop()

    def open_name_color_game(self):
        from name_color_game import NameColorGame
        self.master.destroy()
        new_window = tk.Tk()
        NameColorGame(new_window)
        new_window.mainloop()